# Bootstrap the Claude Agent SDK starter (Windows PowerShell).
# Run from the unzipped folder:  powershell -ExecutionPolicy Bypass -File .\bootstrap.ps1

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

if (-not (Get-Command uv -ErrorAction SilentlyContinue)) {
    Write-Error "uv is not installed. Get it from https://docs.astral.sh/uv/ and rerun."
}

if (-not (Test-Path .env)) {
    Copy-Item .env.example .env
    Write-Host "Created .env from template (key commented out: uses your Claude Code login)."
}

uv sync --locked
uv run pytest -q
uv run main.py "Reply with one short sentence confirming the setup works."
